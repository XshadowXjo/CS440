package fr.esisar.calculatrice;

import java.util.ArrayList;
import java.util.List;

import fr.esisar.calculatrice.operations.Operation;

public class Calculatrice {
	
	private List<Operation> operations = new ArrayList<Operation>();

	public void ajouterOperation(Operation operation) {
		operations.add(operation);
	}
	
	public Operation chercherOperation(String nom) {
		
		Operation rv= null;
		for(Operation op: operations) {
			if(op.getNom().equals(nom))
				rv = op;
		}
		return rv;	 
	}
	
	public Double calculer(String nom, Double operande1, Double operande2) throws CalculatriceException {
		Operation op = chercherOperation(nom);
		if (op.equals(null))
			throw new CalculatriceException("L'opération entrée n'existe pas");
		return op.calculer(operande1, operande2);
		
	}
}
