package fr.esisar.calculatrice;
import fr.esisar.calculatrice.operations.*;

public class Calculateur {

	public static void main(String[] args) {
		Calculatrice calculatrice1 = new Calculatrice();
		Operation addition = new Ajouter();
		Operation soustraction = new Soustraire();
		
		calculatrice1.ajouterOperation(addition);
		calculatrice1.ajouterOperation(soustraction);

		try {
			Double result = calculatrice1.calculer("-", 14.0, 7.0);
			System.out.println("Le resultat est: "+result);
		}
		catch(Exception e){
			e.toString();
		}
	}
}
