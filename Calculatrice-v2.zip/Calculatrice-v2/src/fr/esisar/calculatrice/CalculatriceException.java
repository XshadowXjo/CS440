package fr.esisar.calculatrice;

public class CalculatriceException extends Exception{

	private String message;
	
	public CalculatriceException(String message) {
		this.message = message;
	}
	
	public String toString() {
		return "CalculatriceException [message=" + message + "]";
	}
	
	
}
