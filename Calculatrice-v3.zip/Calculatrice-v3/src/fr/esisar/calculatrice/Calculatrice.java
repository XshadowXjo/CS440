package fr.esisar.calculatrice;

import java.util.HashSet;
import java.util.Set;

import fr.esisar.operations.Operation;

public class Calculatrice {
	private Set<Operation> operations = new HashSet<Operation>();

	public Calculatrice(Set<Operation> operations) {
		this.operations = operations;
	}
	
	public Operation chercherOperation(String nom) {
		Operation rv= null;
		for(Operation op: operations) {
			if(op.getNom().equals(nom))
				rv = op;
		}
		return rv;	 
	}
	public Double calculer(String nom, Double... operandes) throws CalculatriceException {
		Operation op = chercherOperation(nom);
		if (op.equals(null))
			throw new CalculatriceException("Opration inexistante dans la calculatrice");
		return op.calculer(operandes);
	}
	
	public void ajouterOperation(Operation operation) {
		operations.add(operation);
	}
	
	public void retirerOperation(Operation operation) {
		operations.remove(operation);
	}
}
