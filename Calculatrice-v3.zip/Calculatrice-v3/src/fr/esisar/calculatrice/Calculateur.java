package fr.esisar.calculatrice;

import java.util.HashSet;
import java.util.Set;

import fr.esisar.operations.Operation;
import fr.esisar.operations.binaires.Ajouter;
import fr.esisar.operations.binaires.Soustraire;
import fr.esisar.operations.ensemblistes.Maximum;
import fr.esisar.operations.unaires.Cosinus;




public class Calculateur {

	public static void main(String[] args) {
		Operation addition = new Ajouter();
		Operation soustraction = new Soustraire();
		Operation cos = new Cosinus();
		Operation max = new Maximum();
		Set<Operation> op = new HashSet<Operation>();
		op.add(max);
		op.add(cos);
		op.add(soustraction);
		Calculatrice calculatrice1 = new Calculatrice(op);
		calculatrice1.ajouterOperation(addition);

		try {
			Double result = calculatrice1.calculer("-", 14.0, 7.0);
			System.out.println("Le resultat est: "+result);
			result = calculatrice1.calculer("cos", Math.PI);
			System.out.println("cos de pi vaut: "+result);

		}
		catch(Exception e){
			e.toString();
		}
	}
}
