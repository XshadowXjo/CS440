package fr.esisar.operations.unaires;

import fr.esisar.operations.OperationUnaire;

public class Cosinus extends OperationUnaire {

	@Override
	protected Double doCalculer(Double operande) {
		return Math.cos(operande);
	}

	@Override
	public String getNom() {
		return "cos";
	}

}
