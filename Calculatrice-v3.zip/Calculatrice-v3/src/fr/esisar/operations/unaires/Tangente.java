package fr.esisar.operations.unaires;

import fr.esisar.operations.OperationUnaire;

public class Tangente extends OperationUnaire {

	@Override
	protected Double doCalculer(Double operande) {
		return Math.tan(operande);
	}

	@Override
	public String getNom() {
		return "tan";
	}

}
