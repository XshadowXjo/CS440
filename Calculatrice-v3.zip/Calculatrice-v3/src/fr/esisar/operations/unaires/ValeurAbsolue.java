package fr.esisar.operations.unaires;

import fr.esisar.operations.OperationUnaire;

public class ValeurAbsolue extends OperationUnaire {

	@Override
	protected Double doCalculer(Double operande) {
		return Math.abs(operande);
	}

	@Override
	public String getNom() {
		return "abs";
	}

}
