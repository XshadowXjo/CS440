package fr.esisar.operations.unaires;

import fr.esisar.operations.OperationUnaire;

public class Sinus extends OperationUnaire {

	@Override
	protected Double doCalculer(Double operande) {
		return Math.sin(operande);
	}

	@Override
	public String getNom() {
		return "sin";
	}

}
