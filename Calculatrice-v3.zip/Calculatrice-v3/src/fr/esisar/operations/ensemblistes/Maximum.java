package fr.esisar.operations.ensemblistes;

import fr.esisar.operations.OperationEnsembliste;

public class Maximum extends OperationEnsembliste {

	@Override
	public String getNom() {
		return "max";
	}

	@Override
	protected Double doCalculer(Double[] operandes) {
		Double max= operandes[0];
		for(Double nbr: operandes) {
			if(nbr>max)
				max = nbr;
		}
		return max;
	}

}
