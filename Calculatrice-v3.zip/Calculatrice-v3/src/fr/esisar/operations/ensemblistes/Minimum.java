package fr.esisar.operations.ensemblistes;

import fr.esisar.operations.OperationEnsembliste;

public class Minimum extends OperationEnsembliste {

	@Override
	public String getNom() {
		return "min";
	}

	@Override
	protected Double doCalculer(Double[] operandes) {
		Double min= operandes[0];
		for(Double nbr: operandes) {
			if(nbr<min)
				min = nbr;
		}
		return min;
	}

}
