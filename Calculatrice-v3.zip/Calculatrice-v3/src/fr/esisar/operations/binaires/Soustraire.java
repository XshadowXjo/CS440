package fr.esisar.operations.binaires;

import fr.esisar.operations.OperationBinaire;

public class Soustraire extends OperationBinaire {
	
	public String getNom() {
		return "-";
	}
	
	@Override
	protected Double doCalculer(Double operande1, Double operande2) {
		return operande1-operande2;
	}

}
