package fr.esisar.operations.binaires;

import fr.esisar.calculatrice.CalculatriceException;
import fr.esisar.operations.OperationBinaire;

public class Diviser extends OperationBinaire {
	
	public String getNom() {
		return "/";
	}
	
	@Override
	protected Double doCalculer(Double operande1, Double operande2) throws CalculatriceException {
		if(operande2 == 0)
			throw new CalculatriceException("Division par zero");
		return operande1/operande2;
	}

}
