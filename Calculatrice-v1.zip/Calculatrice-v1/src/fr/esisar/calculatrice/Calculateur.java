package fr.esisar.calculatrice;

public class Calculateur {

	public static void main(String[] args) {
		Calculatrice c = new Calculatrice();
		System.out.println("0 + 1 = " +c.ajouter(0, 1));
		System.out.println("0 - 1 = " +c.soustraire(0, 1));
		System.out.println("0 * 1 = " +c.multiplier(0, 1));
		System.out.println("15 / 2 = " +c.diviser(15, 2));
		}
}
