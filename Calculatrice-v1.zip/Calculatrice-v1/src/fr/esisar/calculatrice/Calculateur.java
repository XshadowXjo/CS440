package fr.esisar.calculatrice;

/**
 * Classe de calculateur
 * @author Josias
 * @version 1.0
 */
public class Calculateur {

	/**
	 * test d'opération de la calculatrice.
	 */
	public static void main(String[] args) {
		Calculatrice c = new Calculatrice();
		System.out.println("0 + 1 = " +c.ajouter(0, 1));
		System.out.println("0 - 1 = " +c.soustraire(0, 1));
		System.out.println("0 * 1 = " +c.multiplier(0, 1));
		System.out.println("15 / 2 = " +c.diviser(15, 2));
		}
}
