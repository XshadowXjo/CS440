package fr.esisar.calculatrice;

public class Calculatrice {
	
	public Integer ajouter(Integer operande1, Integer operande2) {
		return operande1 + operande2;	
	}
	
	public Integer soustraire(Integer operande1, Integer operande2) {
			return operande1 - operande2;
	}
	
	public Integer multiplier(Integer operande1, Integer operande2) {
		return operande1 * operande2;
	}
	
	public Float diviser(Integer operande1, Integer operande2) {
		return Float.valueOf(operande1) / operande2;
	}

}


// int est une classe primitive alors que Integer est une classe wrapper qui permet d'encapsuler un int
