package fr.esisar.calculatrice;

/**
 * Classe de calculatrice
 * @author Josias
 * @version 1.0
 */
public class Calculatrice {
	
	/**
	 * Fait l'addition de 2 entiers.
	 * @param operande1   operande 1
	 * @param operande2   operande 2
	 * @return la somme des 2 operandes
	 */
	public Integer ajouter(Integer operande1, Integer operande2) {
		return operande1 + operande2;	
	}
	
	/**
	 * Fait la soustraction de 2 entiers.
	 * @param operande1   operande 1
	 * @param operande2   operande 2
	 * @return la soustraction des 2 operandes
	 */
	public Integer soustraire(Integer operande1, Integer operande2) {
			return operande1 - operande2;
	}
	
	/**
	 * Fait la multiplication de 2 entiers.
	 * @param operande1   operande 1
	 * @param operande2   operande 2
	 * @return la multiplication des 2 operandes
	 */
	public Integer multiplier(Integer operande1, Integer operande2) {
		return operande1 * operande2;
	}
	
	/**
	 * Fait la division de 2 entiers.
	 * @param operande1   operande 1
	 * @param operande2   operande 2
	 * @return le quotient des 2 operandes
	 */
	public Float diviser(Integer operande1, Integer operande2) {
		return Float.valueOf(operande1) / operande2;
	}

}


// int est une classe primitive alors que Integer est une classe wrapper qui permet d'encapsuler un int
